# AERIS Cauca Guardians — V43.0 Premium Mission

Final premium mission build for the AERIS educational experience about the Cauca River, mercury contamination, illegal mining, evidence and responsible action.

## Included
- Responsive English/Spanish experience
- AERIS intro and Guardian identity system
- Mission Map 2.0 with live progression and direct navigation
- Mercury Lab 2.0 pathway visualization
- Evidence Lab and source-first learning flow
- Guardian Challenge 2.0 with evidence-mode feedback
- Guardian Passport with original AERIS achievement artwork
- Guardian Legacy paths using custom badge artwork
- Cauca Guardian AI 2.0 with offline-first field intelligence UI
- Guardian Moves with custom AERIS visual assets
- Mobile and desktop polish with reduced-motion support
- Sources and image credits

The public interface does not expose deployment or infrastructure controls. Worker configuration remains external to the public UI.
